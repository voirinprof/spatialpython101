from qgis.core import QgsGeometry, QgsVectorLayer, QgsField, QgsFeature
from qgis.PyQt.QtCore import  QVariant
from osgeo import gdal
import numpy as np
# voici notre classe d'analyse
class Analyser:

    # on peut définir un constructeur, si on souhaite
    def __init__(self):
        pass

    def setLayer(self, layer):
        self.layer = layer

    def setParam(self, param):
        self.param = param

    # GMQ710 - méthode pour traiter une image
    # le principe est de se baser sur GDAL et la lib NUMPY

    def processRaster(self):

        ds = gdal.Open(self.layer.dataProvider().dataSourceUri())
        # GMQ710 - On récupère les pixels de la bande #1
        pixels_arr = ds.GetRasterBand(1).ReadAsArray()
        # GMQ710 - On effectue un traitement (ex un masque)
        pixels_arr = np.where(pixels_arr <= int(self.param), 0, 255)

        # GMQ710 - Pour créer la couche de sortie, on doit donner le chemin d'un fichier
        filename = r'c:\temp\output.tiff'
        # GMQ710 - On nomme le driver
        driver = gdal.GetDriverByName('GTiff')
        # GMQ710 - on définit la taille de l'image
        dsout = driver.Create(filename, xsize=pixels_arr.shape[1],
                              ysize=pixels_arr.shape[0], bands=1, eType=gdal.GDT_Byte)
        # GMQ710 - On écrit la matrice traitée
        dsout.GetRasterBand(1).WriteArray(pixels_arr)
        # GMQ710 - On utilise la même transformation que l'image en entrée
        dsout.SetGeoTransform(ds.GetGeoTransform())
        # GMQ710 - On utilise le même srs
        dsout.SetProjection(ds.GetProjection())
        dsout = None
        # on retourne à QGis le nom du fichier généré
        return filename

    # GMQ710 - fonction pour traiter une donnée vectorielle

    def process(self):

        allfeatures = self.layer.getFeatures()
        # GMQ710 - on va alimenter une liste
        data = []
        # GMQ710 - on parcourt les entités
        for feature in allfeatures:
            # GMQ710 - on récupère un attribut de l'entité
            typeseg = feature['TYPESEGMEN']
            # GMQ710 - on récupère la géométrie
            geom = feature.geometry()
            # GMQ710 - on va tester si l'entité contient l'info recherchée
            if typeseg == int(self.param):
                # GMQ710 - on ajoute à notre liste
                # Attention, c'est préférable de créer une nouvelle géométrie à partir des infos de
                # l'ancienne donc : QgsGeometry(geom)
                data.append(
                    {'seg': typeseg, 'geom': QgsGeometry(geom)}
                )
        return data

    # GMQ710 - Exemple de la méthode pour créer une couche vectorielle de sortie

    def createLayer(self, data):

        # GMQ710 - on va créer une couche avec les infos de DATA
        # GMQ710 - on récupère la projection
        srs = self.layer.crs()
        # GMQ710 - on va créer une couche vide de type LIGNE (car c'est le même type que le fichier original)
        vl = QgsVectorLayer("LineString?crs=PROJ4:" + srs.toProj4(),
                            "temporary_streets", "memory")
        # GMQ710 - on va créer un provider pour les attributs
        pr = vl.dataProvider()
        # GMQ710 - on définit les attributs
        pr.addAttributes([QgsField("typeseg", QVariant.Int)])
        # GMQ710 - on met à jour la couche
        vl.updateFields()
        # GMQ710 - on parcourt DATA
        for d in data:
            # GMQ710 - on va créer une entité
            fet = QgsFeature()
            # GMQ710 - on ajoute la géométrie
            fet.setGeometry(d['geom'])
            # GMQ710 - on ajoute les infos des attributs
            fet.setAttributes([d['seg']])
            # GMQ710 - on ajoute l'entité à la couche
            pr.addFeatures([fet])
        # GMQ710 - on fait la mise à jour de l'étendue
        vl.updateExtents()

        return vl